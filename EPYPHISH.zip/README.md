# GoC-2022
To use our application you need to create a folder at the root with the scirpt named "mails" and put all the emails to verify in it and launch the script with : "./GoC_app"
